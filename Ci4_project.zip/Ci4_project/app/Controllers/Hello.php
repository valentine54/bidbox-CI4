<?php
namespace App\Controllers;
class Hello extends BaseController{
    public function index(): void
    {
        echo 'Hello World!';
    }
}
