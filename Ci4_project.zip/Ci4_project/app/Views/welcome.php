<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome</title>
    <link rel="stylesheet" href="<?= base_url('css/style.css') ?>">
</head>
<body>
<div class="welcome-container">
    <h1>Welcome to our home page</h1>
    <p>We are glad to have you here!</p>
</div>
</body>
</html>
